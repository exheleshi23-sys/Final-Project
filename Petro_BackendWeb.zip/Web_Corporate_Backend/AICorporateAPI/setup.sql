-- AI CORPORATE DATABASE SETUP
-- Run this inside your AICorporateDB query tool

CREATE TABLE IF NOT EXISTS "Users" (
    "Id" SERIAL PRIMARY KEY,
    "FullName" TEXT NOT NULL,
    "Email" TEXT NOT NULL,
    "Username" TEXT NOT NULL,
    "Role" TEXT
);

CREATE TABLE IF NOT EXISTS "ContactMessages" (
    "Id" SERIAL PRIMARY KEY,
    "Name" TEXT NOT NULL,
    "Email" TEXT NOT NULL,
    "Message" TEXT NOT NULL,
    "CreatedAt" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Test Data (Optional)
INSERT INTO "Users" ("FullName", "Email", "Username", "Role") 
VALUES ('Group Member', 'test@example.com', 'testuser', 'Developer');