using AICorporateAPI.Data;
using AICorporateAPI.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// 1. DATABASE CONNECTION
// Connects to PostgreSQL using the string in your appsettings.json
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

// 2. CORS CONFIGURATION
// This is vital! It allows your HTML files (on port 8080 or file system) 
// to talk to this API (on port 5296).
builder.Services.AddCors(options => {
    options.AddPolicy("AllowFrontend", policy => {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// 3. SWAGGER/OPENAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "AI Corporate API", Version = "v1" });
});

var app = builder.Build();

// 4. MIDDLEWARE PIPELINE
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "AI Corporate API v1"));
}

app.UseCors("AllowFrontend");

// --- 5. USER ENDPOINTS (profile.js) ---

// GET: List all users
app.MapGet("/users", async (AppDbContext db) => 
    await db.Users.ToListAsync());

// POST: Add a new user
app.MapPost("/users", async (User user, AppDbContext db) => {
    db.Users.Add(user);
    await db.SaveChangesAsync();
    return Results.Created($"/users/{user.Id}", user);
});

// DELETE: Remove a user by ID
app.MapDelete("/users/{id}", async (int id, AppDbContext db) => {
    var user = await db.Users.FindAsync(id);
    if (user is null) return Results.NotFound();

    db.Users.Remove(user);
    await db.SaveChangesAsync();
    return Results.NoContent();
});

// --- 6. CONTACT ENDPOINTS (script.js) ---

// POST: Save a contact message from the website
app.MapPost("/contact", async (ContactMessage msg, AppDbContext db) => {
    msg.CreatedAt = DateTime.UtcNow;
    db.ContactMessages.Add(msg);
    await db.SaveChangesAsync();
    return Results.Ok(msg);
});

// GET: View all contact messages (Useful for your admin dashboard)
app.MapGet("/contact", async (AppDbContext db) => 
    await db.ContactMessages.ToListAsync());

app.Run();