/* AI Corporate - Full script.js 
   Connected to .NET 10 API @ http://localhost:5296
*/

// --- 1. MODAL LOGIC ---
const modalBg = document.getElementById("modalBg");

function openModal() {
    modalBg.style.display = "flex";
}

function closeModal() {
    modalBg.style.display = "none";
}

// Close modal if user clicks outside the white box
window.onclick = function(event) {
    if (event.target == modalBg) {
        closeModal();
    }
}

// --- 2. API CONTACT FORM SUBMISSION ---
document.getElementById("contactForm").addEventListener("submit", async function(e) {
    e.preventDefault();

    // Mapping HTML IDs to the C# ContactMessage model properties
    const contactData = {
        name: document.getElementById("contactName").value,
        email: document.getElementById("contactEmail").value,
        message: document.getElementById("contactMessage").value
    };

    try {
        const response = await fetch("http://localhost:5296/contact", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(contactData)
        });

        if (response.ok) {
            const result = await response.json();
            console.log("Success:", result);
            alert("Thank you, " + contactData.name + "! Your message has been sent.");
            
            // Reset form and close modal
            document.getElementById("contactForm").reset();
            closeModal();
        } else {
            const errorMsg = await response.text();
            alert("Submission failed: " + errorMsg);
        }
    } catch (error) {
        console.error("Error connecting to API:", error);
        alert("Server is unreachable. Make sure your .NET API is running on localhost:5296");
    }
});

// --- 3. SCROLL REVEAL (Optional but matches your CSS) ---
// This ensures the "fade-up" classes trigger as you scroll down
const observerOptions = {
    threshold: 0.1
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = "1";
            entry.target.style.transform = "translateY(0)";
        }
    });
}, observerOptions);

document.querySelectorAll('.fade-up').forEach(el => {
    // Initial state before animation triggers
    el.style.opacity = "0";
    el.style.transform = "translateY(30px)";
    el.style.transition = "all 0.8s ease-out";
    observer.observe(el);
});