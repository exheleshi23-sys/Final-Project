const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();
const PORT = 5296; // Matching the port from your existing scripts

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // Assumes HTML files are in a 'public' folder

// --- MOCK DATABASE ---
const users = [
    { email: "admin@ai.com", password: "123", name: "Admin User", role: "Admin" },
    { email: "user@ai.com", password: "123", name: "John Doe", role: "Developer" }
];

const dashboardData = {
    "user@ai.com": {
        stats: { active: 4, completed: 12, notifications: 3, ticket: "99281" },
        messages: ["Welcome to the team!", "Project X is due tomorrow."]
    }
};

// --- ROUTES ---

// 1. Login Endpoint
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    const user = users.find(u => u.email === email && u.password === password);

    if (user) {
        res.json({ success: true, token: "fake-jwt-token", user: user });
    } else {
        res.status(401).json({ success: false, message: "Invalid credentials" });
    }
});

// 2. Dashboard Data Endpoint
app.get('/api/dashboard-data', (req, res) => {
    // In a real app, you'd check the token here.
    // For now, we return default data for the demo.
    res.json(dashboardData["user@ai.com"]);
});

// 3. Contact Form (Connecting your existing Main Page)
app.post('/contact', (req, res) => {
    console.log("Contact form received:", req.body);
    res.json({ message: "Message received!" });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});