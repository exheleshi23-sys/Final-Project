using Microsoft.AspNetCore.Mvc;
using CorporatePortal.Data;
using CorporatePortal.Models;
using System.Linq;
using System;

namespace CorporatePortal.Controllers
{
    [ApiController]
    [Route("api/worktasks")]
    public class WorkTasksController : ControllerBase
    {
        private readonly AppDbContext _context;

        public WorkTasksController(AppDbContext context)
        {
            _context = context;
        }

        
        [HttpPost]
        public IActionResult CreateTask(WorkTask task)
        {
            task.CreatedDate = DateTime.Now;
            task.Status = "Pending";

            _context.WorkTasks.Add(task);
            _context.SaveChanges();

            return Ok("Work task created successfully");
        }

        
        [HttpGet]
        public IActionResult GetTasks()
        {
            var tasks = _context.WorkTasks.ToList();
            return Ok(tasks);
        }

       
        [HttpPut("{id}")]
        public IActionResult UpdateTask(int id, WorkTask updatedTask)
        {
            var task = _context.WorkTasks.Find(id);
            if (task == null)
            {
                return NotFound("Task not found");
            }

            task.Title = updatedTask.Title;
            task.Description = updatedTask.Description;
            task.Status = updatedTask.Status;

            _context.SaveChanges();

            return Ok("Work task updated successfully");
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteTask(int id)
        {
            var task = _context.WorkTasks.Find(id);
            if (task == null)
            {
                return NotFound("Task not found");
            }

            _context.WorkTasks.Remove(task);
            _context.SaveChanges();

            return Ok("Work task deleted successfully");
        }
    }
}

