﻿namespace project_continuation.Models
{
    public class CompanyInfo
    {
        public int Id { get; set; }
        public string CompanyName { get; set; }
        public string AboutText { get; set; }
        public string Slogan { get; set; }
    }
}