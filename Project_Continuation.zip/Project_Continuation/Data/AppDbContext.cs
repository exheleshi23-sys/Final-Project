﻿using Microsoft.EntityFrameworkCore;
using project_continuation.Models;

namespace project_continuation.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<CompanyInfo> CompanyInfos { get; set; }
        public DbSet<Service> Services { get; set; }
        public DbSet<ContactMessage> ContactMessages { get; set; }
    }
}